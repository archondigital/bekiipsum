<?php

/*

Plugin Name: WP-Blogengage
Version: 1.0.2
Plugin URI: http://www.blogengage.com/profile_promo.php
Description: Adds a Blogengage vote button to your posts.


Author: Blog Engage
Author URI: http://www.blogengage.com
*/

$message = "";

if (!function_exists('blogeng_request_handler')) {
    function blogeng_request_handler() {
        global $message;

        if ($_POST['blogeng_action'] == "update options") {
            $blogeng_align_v = $_POST['blogeng_align_sl'];

    		if(get_option("blogeng_box_align")) {
    			update_option("blogeng_box_align", $blogeng_align_v);
    		} else {
    			add_option("blogeng_box_align", $blogeng_align_v);
    		}

            $message = '<br clear="all" /> <div id="message" class="updated fade"><p><strong>Option saved. </strong></p></div>';
        }
    }
}

if(!function_exists('blogeng_add_menu')) {
    function blogeng_add_menu () {
        add_options_page("Blogengage Options", "Blogengage Options", 8, basename(__FILE__), "blogeng_displayOptions");
    }
}

if (!function_exists('blogeng_displayOptions')) {
    function blogeng_displayOptions() {

        global $message;
        echo $message;

		print('<div class="wrap">');
		print('<h2>Blogengage Options</h2>');

        print ('<form name="blogeng_form" action="'. get_bloginfo("wpurl") . '/wp-admin/options-general.php?page=wp-blogengage.php' .'" method="post">');
?>

		<p>Align:
        <select name="blogeng_align_sl" id="blogeng_align_sl">
			<option value="Top Left"   <?php if (get_option("blogeng_box_align") == "Top Left") echo " selected"; ?> >Top Left</option>
			<option value="Top Right"   <?php if (get_option("blogeng_box_align") == "Top Right") echo " selected"; ?> >Top Right</option>
			<option value="Bottom Left"  <?php if (get_option("blogeng_box_align") == "Bottom Left") echo " selected"; ?> >Bottom Left</option>
			<option value="Bottom Right"  <?php if (get_option("blogeng_box_align") == "Bottom Right") echo " selected"; ?> >Bottom Right</option>
			<option value="None"  <?php if (get_option("blogeng_box_align") == "None") echo " selected"; ?> >None</option>
		</select><br /><br /> </p>

<?php
		print ('<p><input type="submit" value="Save &raquo;"></p>');
		print ('<input type="hidden" name="blogeng_action" value="update options" />');
		print('</form></div>');

    }
}


if (!function_exists('blogeng_blogengagehtml')) {
	function blogeng_blogengagehtml($float) {
		global $wp_query;
		$post = $wp_query->post;
		$permalink = get_permalink($post->ID);
        $title = urlencode($post->post_title);
		$blogengagehtml = <<<CODE

    <span style="margin: 0px 6px 0px 0px; float: $float;">

	<script type="text/javascript">
	submit_url = "$permalink";
	</script>
    <script src="http://blogengage.com/evb/button2.php"></script>
	</span>
CODE;
	return  $blogengagehtml;
	}
}


if (!function_exists('blogeng_addbutton')) {
	function blogeng_addbutton($content) {

		if ( !is_feed() && !is_page() && !is_archive() && !is_search() && !is_404() ) {
    		if(! preg_match('|<!--blogengage-->|', $content)) {
    		    $blogeng_align = get_option("blogeng_box_align");
    		    if ($blogeng_align) {
                    switch ($blogeng_align) {
                        case "Top Left":
        		              return blogeng_blogengagehtml("left").$content;
                              break;
                        case "Top Right":
        		              return blogeng_blogengagehtml("Right").$content;
                              break;
                        case "Bottom Left":
        		              return $content.blogeng_blogengagehtml("left");
                              break;
                        case "Bottom Right":
        		              return $content.blogeng_blogengagehtml("right");
                              break;
                        case "None":
        		              return $content;
                              break;
                        default:
        		              return blogeng_blogengagehtml("left").$content;
                              break;
                    }
                } else {
        		      return blogeng_blogengagehtml("left").$content;
                }

    		} else {
                  return str_replace('<!--blogengage-->', blogeng_blogengagehtml(""), $content);
            }
        } else {
			return $content;
        }
	}
}

if (!function_exists('show_blogengage')) {
	function show_blogengage($float = "left") {
        global $post;
		$permalink = get_permalink($post->ID);
		echo <<<CODE

    <span style="margin: 0px 6px 0px 0px; float: $float;">

	<script type="text/javascript">
	submit_url = "$permalink";
	</script>
    echo '<script src="http://blogengage.com/evb/button2.php"></script>';
	</span>
CODE;
    }
}

add_filter('the_content', 'blogeng_addbutton', 999);
add_action('admin_menu', 'blogeng_add_menu');
add_action('init', 'blogeng_request_handler');

?>